NOVA INVEST — DEPLOYMENT

This is a static website. To publish it at nova-invest.vercel.app:
1. Sign in to Vercel and create a new project.
2. Import a Git repository containing index.html, OR use Vercel's supported CLI deployment flow.
3. Deploy the project as a static site (no build command needed; output/root directory is the project root).
4. In Project Settings > Domains, add nova-invest.vercel.app.

The requested subdomain may already be in use. Vercel will confirm availability and may require you to choose another name.

The simulator uses fictional example prices, keeps its state in the current browser session only, and does not execute real trades.
